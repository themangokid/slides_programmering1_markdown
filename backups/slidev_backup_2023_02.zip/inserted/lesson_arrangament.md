---
layout: two-cols
---

# Upplägg måndag
+ En vanlig lektion är följande
  + 10 min: Genomgång
  + 40 min: Arbete
  + 10 min: Rast
  + 30 min: Arbete
    
<br>

###### [Timer till Lektion](https://alxivnov.github.io/Timer/#) 


<!--
Arbete betyder att det kan vara egetarbete men också grupparbete.
https://alxivnov.github.io/Timer/#
-->

::right::


# Upplägg Fredag
+ En vanlig lektion är följande
  + 10 min: Genomgång & Frågor
  + 40 min: Arbete & Redovisning
    
<br>

###### [Timer till Lektion](https://alxivnov.github.io/Timer/#) 