---
layout: two-cols
---

# Left
This shows on the left
::right::

# Right
![animation](anim.png)