---
theme: seriph
title: Programmering_1_kursolle_intro
layout: two-cols
presenter: dev
lineNumbers: true
---

---
src: ./main.md
---


