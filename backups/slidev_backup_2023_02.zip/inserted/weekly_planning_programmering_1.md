
| Vecka | Moment                                                                                                                               | Att göra                         | Kommentar |
| ----- | ------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------- | --------- |
| v34   | Intro                                                                                                                     | Setup                            |           |
| v35   | [](https://www.kursolle.se/prrprr01/moment02.php)[Moment02 - Grunderna (Datatyper)](https://www.kursolle.se/prrprr01/moment02.php)   | m02u03, m02u04, (Utbyggnad 1, 2) |           |
| v36   | [](https://www.kursolle.se/prrprr01/moment02.php)[Moment02 - Grunderna (Datatyper)](https://www.kursolle.se/prrprr01/moment02.php)   | m02u03, m02u04, (Utbyggnad 1, 2) |           |
| v37   | [](https://www.kursolle.se/prrprr01/moment03.php)[Moment03 - Selektioner (if-satser)](https://www.kursolle.se/prrprr01/moment03.php) | Alla, men ej: m03u06             |           |
| v38   | [](https://www.kursolle.se/prrprr01/moment04.php)[Moment04 - Iterationer (for-loop)](https://www.kursolle.se/prrprr01/moment04.php)  | Alla uppgifter                   |           |
| v39   | [](https://kursolle.se/prrprr01/moment05.php)[Moment05 - Funktioner och datalagring](https://kursolle.se/prrprr01/moment05.php)      | Alla uppgifter                   |           |
| v40   | [](https://kursolle.se/prrprr01/moment06.php)[Moment06 - Moduler och paket](https://kursolle.se/prrprr01/moment06.php)               | Alla uppgifter                   |           |
| v41   | [](https://kursolle.se/prrprr01/projekt01.php)[P01 Bankapplikation](https://kursolle.se/prrprr01/projekt01.php)                      | Slutuppgift                      |           |
